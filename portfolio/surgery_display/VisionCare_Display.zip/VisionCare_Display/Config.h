#pragma once

#ifndef D0
#define D0 2
#endif

const char* AP_SSID = "VisionCare_Display";
const char* AP_PASS = "";  // blank = open Wi-Fi. Use 8+ chars for WPA2.

IPAddress apIP(192, 168, 4, 1);
IPAddress netMask(255, 255, 255, 0);

const byte DNS_PORT = 53;
const int HELP_SWITCH_PIN = D0;
const unsigned long SWITCH_DEBOUNCE_MS = 35;

const int MAX_PATIENTS = 60;
const int MAX_ANNOUNCEMENTS = 20;
