#pragma once

bool lastRawSwitchState = HIGH;
bool stableSwitchState = HIGH;
unsigned long lastSwitchChangeMs = 0;

void checkHelpSwitch() {
  bool raw = digitalRead(HELP_SWITCH_PIN);

  if (raw != lastRawSwitchState) {
    lastRawSwitchState = raw;
    lastSwitchChangeMs = millis();
  }

  if ((millis() - lastSwitchChangeMs) > SWITCH_DEBOUNCE_MS && raw != stableSwitchState) {
    stableSwitchState = raw;

    if (stableSwitchState == LOW) {
      store.toggleHelp();
    }
  }
}
