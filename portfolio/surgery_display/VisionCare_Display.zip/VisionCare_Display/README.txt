VisionCare Display C3 Rebuilt

Upload VisionCare_Display_C3_rebuilt.ino to a Seeed XIAO ESP32C3.

Wi-Fi:
  SSID: VisionCare_Display
  URL:  http://192.168.4.1

Switch:
  D0 -> normally-open switch -> GND

This rebuild uses the architecture that worked in the interaction debug sketch:
- ESP32 owns all state.
- Browser sends tiny GET actions through /act.
- Display polls /api/display with cache-busting.
- No localStorage.
- No fetch().
- No async/await.
- No String.replaceAll().
- Fixed 1024 x 768 display area, with responsive shrink if screen is smaller.
- Audio alerts require tapping "Enable / test audio" on the display tablet once.


Audio/UI patch:
- Alert sound triggers now use pulse IDs instead of one-time booleans.
- This prevents the first polling device from consuming the event before the display tablet hears it.
- Each browser remembers the last pulse ID it heard, so it only speaks each alert once.
- Button spacing and section styling were cleaned up.
