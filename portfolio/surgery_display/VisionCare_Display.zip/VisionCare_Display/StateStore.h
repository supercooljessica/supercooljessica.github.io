#pragma once

struct Patient {
  int id;
  int number;
  String name;
  String status; // queue, surgery, done
};

struct Announcement {
  int id;
  String text;
  int seconds;
};

class StateStore {
public:
  Patient patients[MAX_PATIENTS];
  Announcement announcements[MAX_ANNOUNCEMENTS];

  int patientCount;
  int announcementCount;
  int nextId;
  int capacity;
  long clockOffsetMs;
  bool helpActive;
  unsigned long announcementPulseId;
  unsigned long helpPulseId;
  unsigned long version;

  StateStore() {
    patientCount = 0;
    announcementCount = 0;
    nextId = 1;
    capacity = 2;
    clockOffsetMs = 0;
    helpActive = false;
    announcementPulseId = 0;
    helpPulseId = 0;
    version = 1;
  }

  void touch() {
    version++;
    if (version == 0) version = 1;
  }

  int clampInt(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
  }

  String htmlEsc(String s) {
    String o = "";
    for (unsigned int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '&') o += "&amp;";
      else if (c == '<') o += "&lt;";
      else if (c == '>') o += "&gt;";
      else if (c == '"') o += "&quot;";
      else o += c;
    }
    return o;
  }

  String jsEsc(String s) {
    String o = "";
    for (unsigned int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (c == '\\') o += "\\\\";
      else if (c == '"') o += "\\\"";
      else if (c == '\n') o += "\\n";
      else if (c == '\r') {}
      else o += c;
    }
    return o;
  }

  int findPatient(int id) {
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].id == id) return i;
    }
    return -1;
  }

  int findAnnouncement(int id) {
    for (int i = 0; i < announcementCount; i++) {
      if (announcements[i].id == id) return i;
    }
    return -1;
  }

  int nextPatientNumber() {
    int maxNum = 0;
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].number > maxNum) maxNum = patients[i].number;
    }
    return clampInt(maxNum + 1, 1, 99);
  }

  int waitingCount() {
    int n = 0;
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].status != "done" && patients[i].status != "surgery") n++;
    }
    return n;
  }

  int surgeryCount() {
    int n = 0;
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].status == "surgery") n++;
    }
    return n;
  }

  void addPatient(int number, String name) {
    if (patientCount >= MAX_PATIENTS) return;
    Patient p;
    p.id = nextId++;
    p.number = clampInt(number, 1, 99);
    p.name = name;
    p.status = "queue";

    int firstDone = -1;
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].status == "done") {
        firstDone = i;
        break;
      }
    }

    if (firstDone < 0) {
      patients[patientCount++] = p;
    } else {
      for (int i = patientCount; i > firstDone; i--) {
        patients[i] = patients[i - 1];
      }
      patients[firstDone] = p;
      patientCount++;
    }

    touch();
  }

  void editPatient(int id, int number, String name) {
    int i = findPatient(id);
    if (i < 0) return;
    patients[i].number = clampInt(number, 1, 99);
    patients[i].name = name;
    touch();
  }

  void deletePatient(int id) {
    int idx = findPatient(id);
    if (idx < 0) return;
    for (int i = idx; i < patientCount - 1; i++) {
      patients[i] = patients[i + 1];
    }
    patientCount--;
    touch();
  }

  void movePatient(int id, int dir) {
    int i = findPatient(id);
    int j = i + dir;
    if (i < 0 || j < 0 || j >= patientCount) return;
    Patient t = patients[i];
    patients[i] = patients[j];
    patients[j] = t;
    touch();
  }

  void movePatientToBottom(int idx) {
    if (idx < 0 || idx >= patientCount) return;
    Patient p = patients[idx];
    for (int i = idx; i < patientCount - 1; i++) {
      patients[i] = patients[i + 1];
    }
    patients[patientCount - 1] = p;
  }

  void movePatientToBottomActive(int idx) {
    if (idx < 0 || idx >= patientCount) return;
    Patient p = patients[idx];

    for (int i = idx; i < patientCount - 1; i++) {
      patients[i] = patients[i + 1];
    }

    int insertAt = patientCount - 1;
    for (int i = 0; i < patientCount - 1; i++) {
      if (patients[i].status == "done") {
        insertAt = i;
        break;
      }
    }

    for (int i = patientCount - 1; i > insertAt; i--) {
      patients[i] = patients[i - 1];
    }
    patients[insertAt] = p;
  }

  bool setPatientStatus(int id, String status) {
    int i = findPatient(id);
    if (i < 0) return false;

    if (status == "surgery") {
      if (patients[i].status != "surgery" && surgeryCount() >= capacity) return false;
      patients[i].status = "surgery";
    } else if (status == "done") {
      patients[i].status = "done";
      movePatientToBottom(i);
    } else {
      patients[i].status = "queue";
      movePatientToBottomActive(i);
    }

    touch();
    return true;
  }

  void addAnnouncement(String text, int seconds) {
    if (announcementCount >= MAX_ANNOUNCEMENTS) return;
    announcements[announcementCount].id = nextId++;
    announcements[announcementCount].text = text;
    announcements[announcementCount].seconds = clampInt(seconds, 1, 60);
    announcementCount++;
    touch();
    announcementPulseId = version;
  }

  void editAnnouncement(int id, String text, int seconds) {
    int i = findAnnouncement(id);
    if (i < 0) return;
    announcements[i].text = text;
    announcements[i].seconds = clampInt(seconds, 1, 60);
    touch();
  }

  void deleteAnnouncement(int id) {
    int idx = findAnnouncement(id);
    if (idx < 0) return;
    for (int i = idx; i < announcementCount - 1; i++) {
      announcements[i] = announcements[i + 1];
    }
    announcementCount--;
    touch();
  }

  void moveAnnouncement(int id, int dir) {
    int i = findAnnouncement(id);
    int j = i + dir;
    if (i < 0 || j < 0 || j >= announcementCount) return;
    Announcement t = announcements[i];
    announcements[i] = announcements[j];
    announcements[j] = t;
    touch();
  }

  void setCapacity(int c) {
    capacity = clampInt(c, 1, 12);
    touch();
  }

  void setClockOffset(long offset) {
    clockOffsetMs = offset;
    touch();
  }

  void setHelp(bool active) {
    bool wasActive = helpActive;
    helpActive = active;
    touch();
    if (!wasActive && active) {
      helpPulseId = version;
    }
  }

  void toggleHelp() {
    setHelp(!helpActive);
  }

  String displayJson() {
    String j = "{";
    j += "\"version\":" + String(version);
    j += ",\"offset\":" + String(clockOffsetMs);
    j += ",\"capacity\":" + String(capacity);
    j += ",\"waiting\":" + String(waitingCount());
    j += ",\"help\":" + String(helpActive ? "true" : "false");
    j += ",\"annPulseId\":" + String(announcementPulseId);
    j += ",\"helpPulseId\":" + String(helpPulseId);

    j += ",\"surgery\":[";
    bool first = true;
    for (int i = 0; i < patientCount; i++) {
      if (patients[i].status == "surgery") {
        if (!first) j += ",";
        j += String(patients[i].number);
        first = false;
      }
    }
    j += "]";

    j += ",\"announcements\":[";
    for (int i = 0; i < announcementCount; i++) {
      if (i) j += ",";
      j += "{\"id\":" + String(announcements[i].id);
      j += ",\"text\":\"" + jsEsc(announcements[i].text) + "\"";
      j += ",\"seconds\":" + String(announcements[i].seconds) + "}";
    }
    j += "]}";

    return j;
  }
};
