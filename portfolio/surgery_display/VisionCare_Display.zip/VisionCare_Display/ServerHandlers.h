#pragma once

void noCache() {
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  server.sendHeader("Pragma", "no-cache");
  server.sendHeader("Expires", "0");
}

void sendPage() {
  noCache();
  server.send(200, "text/html", buildPage());
}

String arg(String name) {
  if (server.hasArg(name)) return server.arg(name);
  return "";
}

void redirectRoot() {
  server.sendHeader("Location", "http://192.168.4.1/", true);
  server.send(302, "text/plain", "");
}

void handleDisplayApi() {
  noCache();
  server.send(200, "application/json", store.displayJson());
}

long parseTimeOffset(String t) {
  int c = t.indexOf(':');
  if (c < 0) return store.clockOffsetMs;
  int hh = t.substring(0, c).toInt();
  int mm = t.substring(c + 1).toInt();
  unsigned long now = millis();
  long target = (long)hh * 3600000L + (long)mm * 60000L;
  long current = now % 86400000L;
  return target - current;
}

void handleAction() {
  String a = arg("a");
  bool ok = true;

  if (a == "helpOn") store.setHelp(true);
  else if (a == "helpOff") store.setHelp(false);

  else if (a == "annAdd") store.addAnnouncement(arg("text"), arg("seconds").toInt());
  else if (a == "annEdit") store.editAnnouncement(arg("id").toInt(), arg("text"), arg("seconds").toInt());
  else if (a == "annDel") store.deleteAnnouncement(arg("id").toInt());
  else if (a == "annUp") store.moveAnnouncement(arg("id").toInt(), -1);
  else if (a == "annDown") store.moveAnnouncement(arg("id").toInt(), 1);

  else if (a == "patAdd") store.addPatient(arg("num").toInt(), arg("name"));
  else if (a == "patEdit") store.editPatient(arg("id").toInt(), arg("num").toInt(), arg("name"));
  else if (a == "patDel") store.deletePatient(arg("id").toInt());
  else if (a == "patUp") store.movePatient(arg("id").toInt(), -1);
  else if (a == "patDown") store.movePatient(arg("id").toInt(), 1);
  else if (a == "patSurgery") ok = store.setPatientStatus(arg("id").toInt(), "surgery");
  else if (a == "patDone") ok = store.setPatientStatus(arg("id").toInt(), "done");
  else if (a == "patQueue") ok = store.setPatientStatus(arg("id").toInt(), "queue");

  else if (a == "capUp") store.setCapacity(store.capacity + 1);
  else if (a == "capDown") store.setCapacity(store.capacity - 1);
  else if (a == "setTime") store.setClockOffset(parseTimeOffset(arg("time")));

  if (!ok) {
    noCache();
    server.send(200, "text/html", "<html><body style='font-family:Arial'><h2>Surgery capacity is full</h2><p>Mark someone done before adding another patient to surgery.</p><p><a href='/'>Back</a></p></body></html>");
  } else {
    redirectRoot();
  }
}

void handleNotFound() {
  String uri = server.uri();
  if (uri.indexOf("generate_204") >= 0 ||
      uri.indexOf("gen_204") >= 0 ||
      uri.indexOf("hotspot-detect") >= 0 ||
      uri.indexOf("connecttest") >= 0 ||
      uri.indexOf("ncsi") >= 0 ||
      uri.indexOf("fwlink") >= 0) {
    redirectRoot();
  } else {
    sendPage();
  }
}
