#pragma once

String pageHeader() {
  String h = "";
  h += "<!doctype html><html><head><meta charset='utf-8'>";
  h += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  h += "<title>VisionCare Display</title>";
  h += "<style>";
  h += "html,body{margin:0;padding:0;background:#101114;color:#f7f7f7;font-family:Arial,Helvetica,sans-serif}";
  h += "*{box-sizing:border-box}";
  h += "#display{width:1024px;height:768px;background:#000;color:#fff;position:relative;overflow:hidden;border-bottom:4px solid #333;max-width:100%}";
  h += "#display.help{background:#b00000}";
  h += "#displayTable{display:table;width:100%;height:100%}";
  h += "#displayCell{display:table-cell;vertical-align:middle;text-align:center;font-weight:bold;line-height:1.08;padding:34px;font-size:72px}";
  h += ".smallLine{font-size:.42em;line-height:1.05}.bigLine{font-size:1em;white-space:nowrap}.waitLine{font-size:.46em;white-space:nowrap}";
  h += "#closeHelp{display:none;position:absolute;right:20px;bottom:20px;background:#fff;color:#a00000;border:0;border-radius:28px;padding:14px 24px;font-weight:bold;font-size:22px}";
  h += "#display.help #closeHelp{display:block}";
  h += "#controls{max-width:1024px;padding:14px}";
  h += "section{background:#1b1d22;border:1px solid #333944;border-radius:12px;padding:14px;margin:0 0 14px}";
  h += "h2{margin:0 0 10px;font-size:22px}label{display:block;color:#aeb4bf;margin:8px 0 4px}";
  h += "input,textarea,button{font:inherit;border-radius:8px;border:1px solid #555}input,textarea{padding:10px;background:#101217;color:#fff}textarea{height:72px}";
  h += "button{padding:10px 12px;background:#262a31;color:#fff}.primary{background:#12508a}.danger{background:#662222}.ok{background:#1f5b2a}.warn{background:#705415}";
  h += ".row{display:table;width:100%;border-spacing:8px 0}.cell{display:table-cell;vertical-align:bottom}.wide{width:100%}.num{width:88px}.dur{width:88px}.actions{white-space:nowrap}";
  h += ".item{display:table;width:100%;border-spacing:6px 0;background:#262a31;border:1px solid #414855;border-radius:10px;padding:8px;margin:8px 0}";
  h += ".surgery{background:#164d80}.done{background:#292b30;color:#aaa}.done input{color:#aaa;text-decoration:line-through}";
  h += ".hint{color:#aeb4bf;font-size:14px}.msg{background:#8b1e1e;color:#fff;padding:10px;border-radius:8px;margin:8px 0;display:none}";
  h += "@media(max-width:700px){#display{width:100vw;height:75vw}#displayCell{padding:20px}.row,.cell{display:block;width:100%}.cell{margin-bottom:8px}.actions button{margin:3px}}";
  h += "</style></head><body>";
  return h;
}

String pageScript() {
  String s = "";
  s += "<script type='text/javascript'>";
  s += "var data=null,slideIndex=0,timer=null,audioEnabled=false,lastVersion=0;";
  s += "function id(x){return document.getElementById(x)}";
  s += "function esc(t){return String(t==null?'':t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}";
  s += "function xhr(u,cb){var r=new XMLHttpRequest();r.onreadystatechange=function(){if(r.readyState==4){cb(r.status,r.responseText)}};r.open('GET',u,true);r.setRequestHeader('Cache-Control','no-cache');r.send(null)}";
  s += "function speak(t){if(!audioEnabled)return;try{if(window.speechSynthesis&&window.SpeechSynthesisUtterance){window.speechSynthesis.cancel();var u=new SpeechSynthesisUtterance(t);u.rate=1;u.volume=1;window.speechSynthesis.speak(u);return}}catch(e){}try{var C=window.AudioContext||window.webkitAudioContext;if(!C)return;var c=new C(),o=c.createOscillator(),g=c.createGain();o.frequency.value=880;g.gain.value=.18;o.connect(g);g.connect(c.destination);o.start(0);setTimeout(function(){o.stop(0);c.close()},220)}catch(e){}}";
  s += "function time12(){var d=new Date((new Date()).getTime()+Number(data.offset||0)),h=d.getHours(),m=d.getMinutes(),ap=h>=12?'PM':'AM';h=h%12;if(h==0)h=12;return h+':'+(m<10?'0':'')+m+' '+ap}";
  s += "function slides(){var a=[{kind:'text',text:time12(),seconds:3}],i;for(i=0;i<data.announcements.length;i++){a.push({kind:'text',text:data.announcements[i].text,seconds:data.announcements[i].seconds})}var cap=Number(data.capacity||2),slots=[];for(i=0;i<cap;i++){slots.push(data.surgery[i]?('#'+data.surgery[i]):'-')}a.push({kind:'html',seconds:3,text:'<div class=\"smallLine\">IN SURGERY</div><div class=\"bigLine\">'+esc(slots.join(' | '))+'</div><div class=\"waitLine\">NUM WAITING: '+esc(data.waiting)+'</div>'});return a}";
  s += "function fit(){var box=id('display'),cell=id('displayCell'),lo=12,hi=280,b=12,m,i;for(i=0;i<13;i++){m=Math.floor((lo+hi)/2);cell.style.fontSize=m+'px';if(cell.scrollWidth<=box.clientWidth&&cell.scrollHeight<=box.clientHeight){b=m;lo=m+1}else{hi=m-1}}cell.style.fontSize=b+'px'}";
  s += "function render(){if(!data)return;var d=id('display'),c=id('displayCell');if(data.help){d.className='help';c.innerHTML='Dr. Park requests help';fit();return}d.className='';var sl=slides();if(slideIndex>=sl.length)slideIndex=0;if(sl[slideIndex].kind=='html')c.innerHTML=sl[slideIndex].text;else c.innerHTML=esc(sl[slideIndex].text);fit()}";
  s += "function schedule(){clearTimeout(timer);var sl=data?slides():[{seconds:3}],dur=(sl[slideIndex]&&sl[slideIndex].seconds?sl[slideIndex].seconds:3)*1000;timer=setTimeout(function(){if(data&&!data.help){slideIndex=(slideIndex+1)%slides().length}render();schedule()},dur)}";
  s += "function poll(){xhr('/api/display?t='+(new Date()).getTime(),function(st,txt){if(st!=200)return;try{var n=JSON.parse(txt);data=n;if(n.version!=lastVersion){lastVersion=n.version;render()}if(n.annPulse)speak('new announcement');if(n.helpPulse)speak('help requested')}catch(e){}})}";
  s += "function action(a){xhr('/act?a='+encodeURIComponent(a)+'&t='+(new Date()).getTime(),function(){poll()});return false}";
  s += "window.onload=function(){var b=id('enableAudio');if(b)b.onclick=function(){audioEnabled=true;speak('audio enabled');id('msg').style.display='block';id('msg').innerHTML='Audio enabled on this device.'};poll();schedule();setInterval(poll,1500);setInterval(render,1000)};";
  s += "</script>";
  return s;
}

String buildPage() {
  String h = pageHeader();

  h += "<div id='display'><div id='displayTable'><div id='displayCell'>Loading display...</div></div>";
  h += "<form method='get' action='/act'><input type='hidden' name='a' value='helpOff'><button id='closeHelp'>Close</button></form></div>";

  h += "<div id='controls'>";
  h += "<div id='msg' class='msg'></div>";

  h += "<section><h2>Help alert</h2>";
  h += "<form method='get' action='/act'><button name='a' value='helpOn' class='danger'>Show Dr. Park requests help</button></form>";
  h += "<p class='hint'>D0 switch toggles this on/off.</p></section>";

  h += "<section><h2>Add announcement</h2>";
  h += "<form method='get' action='/act'><input type='hidden' name='a' value='annAdd'>";
  h += "<div class='row'><div class='cell wide'><label>Announcement</label><textarea name='text'></textarea></div>";
  h += "<div class='cell dur'><label>Seconds</label><input name='seconds' type='number' min='1' max='60' value='3' style='width:80px'></div>";
  h += "<div class='cell actions'><button class='primary'>Add</button></div></div></form>";

  for (int i = 0; i < store.announcementCount; i++) {
    Announcement &a = store.announcements[i];
    h += "<form class='item' method='get' action='/act'><input type='hidden' name='id' value='" + String(a.id) + "'>";
    h += "<span class='cell actions'><button name='a' value='annUp'>↑</button><button name='a' value='annDown'>↓</button></span>";
    h += "<span class='cell wide'><input name='text' value=\"" + store.htmlEsc(a.text) + "\" style='width:100%'></span>";
    h += "<span class='cell dur'><input name='seconds' type='number' min='1' max='60' value='" + String(a.seconds) + "' style='width:72px'></span>";
    h += "<span class='cell actions'><button class='primary' name='a' value='annEdit'>Save</button><button class='danger' name='a' value='annDel'>Delete</button></span></form>";
  }
  h += "</section>";

  h += "<section><h2>Patient queue</h2>";
  h += "<form method='get' action='/act'><input type='hidden' name='a' value='patAdd'>";
  h += "<div class='row'><div class='cell num'><label>Queue #</label><input name='num' type='number' min='1' max='99' value='" + String(store.nextPatientNumber()) + "' style='width:80px'></div>";
  h += "<div class='cell wide'><label>Last name</label><input name='name' style='width:100%'></div>";
  h += "<div class='cell actions'><button class='primary'>Add</button></div></div></form>";

  for (int i = 0; i < store.patientCount; i++) {
    Patient &p = store.patients[i];
    String cls = "item";
    if (p.status == "surgery") cls += " surgery";
    if (p.status == "done") cls += " done";
    h += "<form class='" + cls + "' method='get' action='/act'><input type='hidden' name='id' value='" + String(p.id) + "'>";
    h += "<span class='cell actions'><button name='a' value='patUp'>↑</button><button name='a' value='patDown'>↓</button></span>";
    h += "<span class='cell num'><input name='num' type='number' min='1' max='99' value='" + String(p.number) + "' style='width:70px'></span>";
    h += "<span class='cell wide'><input name='name' value=\"" + store.htmlEsc(p.name) + "\" style='width:100%'></span>";
    h += "<span class='cell actions'><button class='primary' name='a' value='patEdit'>Save</button>";
    if (p.status != "surgery") h += "<button name='a' value='patSurgery'>In surgery</button>";
    if (p.status == "surgery") h += "<button class='warn' name='a' value='patQueue'>Back</button>";
    if (p.status != "done") h += "<button class='ok' name='a' value='patDone'>Done</button>";
    else h += "<button class='warn' name='a' value='patQueue'>Undo</button>";
    h += "<button class='danger' name='a' value='patDel'>Delete</button></span></form>";
  }
  h += "</section>";

  h += "<section><h2>Setup</h2>";
  h += "<button id='enableAudio' type='button' class='primary'>Enable / test audio</button>";
  h += "<form method='get' action='/act'><label>Set current time</label><input name='time' type='time'><button name='a' value='setTime' class='primary'>Set time</button></form>";
  h += "<form method='get' action='/act'><label>Surgery capacity</label><button name='a' value='capDown'>−</button> <input readonly value='" + String(store.capacity) + "' style='width:60px;text-align:center'> <button name='a' value='capUp'>+</button></form>";
  h += "<label>Direct browser link</label><input value='http://192.168.4.1' readonly style='width:260px'> <span class='hint'>Long-press to copy.</span>";
  h += "</section></div>";

  h += pageScript();
  h += "</body></html>";
  return h;
}
