#pragma once

void setupWiFi() {
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(apIP, apIP, netMask);

  if (strlen(AP_PASS) >= 8) {
    WiFi.softAP(AP_SSID, AP_PASS);
  } else {
    WiFi.softAP(AP_SSID);
  }

  dnsServer.start(DNS_PORT, "*", apIP);
}

void setupServer() {
  server.on("/", HTTP_GET, sendPage);
  server.on("/act", HTTP_GET, handleAction);
  server.on("/api/display", HTTP_GET, handleDisplayApi);

  server.on("/generate_204", HTTP_GET, redirectRoot);
  server.on("/gen_204", HTTP_GET, redirectRoot);
  server.on("/hotspot-detect.html", HTTP_GET, redirectRoot);
  server.on("/connecttest.txt", HTTP_GET, redirectRoot);
  server.on("/ncsi.txt", HTTP_GET, redirectRoot);
  server.on("/fwlink", HTTP_GET, redirectRoot);

  server.onNotFound(handleNotFound);
  server.begin();
}
