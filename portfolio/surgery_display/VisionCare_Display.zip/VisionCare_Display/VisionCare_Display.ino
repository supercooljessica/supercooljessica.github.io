/*
  VisionCare Display - rebuilt for old Android compatibility

  Board: Seeed Studio XIAO ESP32C3
  Wi-Fi SSID: VisionCare_Display
  URL: http://192.168.4.1

  Limit switch:
    D0 -> normally-open switch -> GND
    Each press toggles the help alert on/off.

  Architecture:
    - ESP32 is the only source of truth.
    - Browsers send small actions only.
    - Display polls a small JSON endpoint.
    - JavaScript is ES5-style for Android 5.1.1 compatibility.
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>

#include "Config.h"
#include "StateStore.h"

DNSServer dnsServer;
WebServer server(80);
StateStore store;

#include "Page.h"
#include "ServerHandlers.h"
#include "NetworkSetup.h"
#include "SwitchHandler.h"

void setup() {
  pinMode(HELP_SWITCH_PIN, INPUT_PULLUP);
  setupWiFi();
  setupServer();
}

void loop() {
  dnsServer.processNextRequest();
  server.handleClient();
  checkHelpSwitch();
}
